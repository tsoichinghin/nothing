import pyautogui
import time
import os
import cv2
import numpy as np
import subprocess

def prepare_images():
    current_working_directory = os.getcwd()
    images_folder = os.path.join(current_working_directory, "images")
    user = None
    for filename in os.listdir(images_folder):
        if filename.endswith(".png") or filename.endswith(".jpg"):
            image_path = os.path.join(images_folder, filename)
            image = cv2.imread(image_path)
            if image is not None:
                if filename == 'loading.png':
                    loading = image
                    print("Loading.png sucessed to loading")
                elif filename == 'norespond.png':
                    norespond = image
                else:
                    print(f"Unknown image filename: {filename}")
            else:
                print(f"Failed to load image: {image_path}")
    return loading, norespond


def close_app():
    loading, norespond = prepare_images()
    time.sleep(1)
    while True:
        screenshot = result_1 = result_2 = min_val_1 = max_val_1 = min_loc_1 = max_loc_1 = min_val_2 = max_val_2 = min_loc_2 = max_loc_2 = None
        min_x, max_x = 0, 1919
        min_y, max_y = 0, 1079
        width = max_x - min_x
        height = max_y - min_y
        screenshot = pyautogui.screenshot(region=(min_x, min_y, width, height))
        screenshot = np.array(screenshot)
        result_1 = cv2.matchTemplate(screenshot, loading, cv2.TM_CCOEFF_NORMED)
        result_2 = cv2.matchTemplate(screenshot, norespond, cv2.TM_CCOEFF_NORMED)
        min_val_1, max_val_1, min_loc_1, max_loc_1 = cv2.minMaxLoc(result_1)
        min_val_2, max_val_2, min_loc_2, max_loc_2 = cv2.minMaxLoc(result_2)
        if min_val_1 is not None and max_val_1 is not None and min_loc_1 is not None and max_loc_1 is not None:
            print("Found loading")
            time.sleep(1)
        elif min_val_2 is not None and max_val_2 is not None and min_loc_2 is not None and max_loc_2 is not None:
            print("Found norespond")
            time.sleep(1)
        else:
            print("Not found.")

close_app()