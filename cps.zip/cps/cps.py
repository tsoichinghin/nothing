import pyautogui
import time

def close_app():
    while True:
        pyautogui.leftClick(1208, 373)
        print("Withdrawn closed")
        time.sleep(5)
        pyautogui.leftClick(1406, 260)
        print("PacketShare closed")
        time.sleep(5)
        pyautogui.leftClick(145,45)
        print("Wine closed")
        time.sleep(5)

close_app()